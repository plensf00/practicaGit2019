package es.unileon.prg1.ticTacToe;

import javax.swing.Icon;

public class Mark {

	private Icon icon;
	
	public Mark(Icon icon){
		this.icon = icon;
	}
	
	public Icon getIcon(){
		return this.icon;
	}
	
}
